JARVIS Android WebView wrapper project

This is an Android Studio project that packages the supplied jarvis.html inside an Android app.
It is not a precompiled APK. Build it with Android Studio to produce the APK.

BUILD:
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open the JARVIS-Android folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK/build tools.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the debug APK at:
   app/build/outputs/apk/debug/app-debug.apk
6. Transfer it to your Android phone and install it. You may need to allow installation
   from that file manager/browser in Android settings.

MICROPHONE:
The app requests RECORD_AUDIO only when the embedded page asks to use the microphone.
Grant it to use speech features. Web Speech recognition availability depends on the
Android System WebView version and installed speech services.

LIMITATIONS:
- This wraps the existing HTML in Android WebView; it does not grant unrestricted system access.
- Opening external web pages/apps is delegated to Android.
- Always-on background wake word, SMS/notification access, changing system settings,
  reliable alarm creation, and full app control need dedicated native Android code,
  additional permissions, and in some cases special default-app roles.
- The HTML AI endpoint must be an HTTPS backend. Do not put API secrets in the HTML.
- The local HTML can use browser storage; clearing app data removes it.
- Network news and AI functions require working backend endpoints.

PACKAGE:
com.example.jarvis
App name: JARVIS
